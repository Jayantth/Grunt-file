
var bio = {
    "name": "Jayantth Ganesh",
    "role": "web developer",
    "contacts": {
        "mobile": "9659977744",
        "email": "jayanth.ganesh07@gmail.com",
        "github": "jayantth",
        "skype": "jayanth3529",
        "location": "Chennai"
    },
    "welcomeMessage": "Hola amigo",
    "skills": ["Photography", "WebDesigning", "Gaming", "Racing"],
    "biopic": "images/fry.jpg"
};

bio.display = function() {

    var formattedname = HTMLheaderName.replace("%data%", bio.name);
    var formattedrole = HTMLheaderRole.replace("%data%", bio.role);
    var formattednamerole = formattedname + formattedrole;
    $("#header").prepend(formattednamerole);

    var formattedmobile = HTMLmobile.replace("%data%", bio.contacts.mobile);
    $("#topContacts, #footerContacts").append(formattedmobile);

    var formattedemail = HTMLemail.replace("%data%", bio.contacts.email);
    $("#topContacts, #footerContacts").append(formattedemail);

    var formattedskype = HTMLtwitter.replace("%data%", bio.contacts.skype);
    $("#topContacts, #footerContacts").append(formattedskype);

    var formattedgithub = HTMLgithub.replace("%data%", bio.contacts.github);
    $("#topContacts, #footerContacts").append(formattedgithub);
    $("#footerContacts").append(formattedgithub);

    var formattedloc = HTMLlocation.replace("%data%", bio.contacts.location);
    $("#topContacts, #footerContacts").append(formattedloc);

    var formattedwelcome = HTMLwelcomeMsg.replace("%data%", bio.welcomeMessage);
    $("#header").append(formattedwelcome);

    var formattedpic = HTMLbioPic.replace("%data%", bio.biopic);
    $("#header").append(formattedpic);

    $("#header").append(HTMLskillsStart);
    bio.skills.forEach(function(skill) {
        var formattedSkill = HTMLskills.replace("%data%", skill);
        $("#skills").append(formattedSkill);
    });
};

bio.display();

var work = {
    "jobs": [{
        "employer": "Infosys",
        "title": "system engineer",
        "dates": "jan-2017(Future)",
        "location": "Mysore",
        "description": "Infosys is one of the biggest IT based multi-national company. It has a 350 acre wide spread training centre in Mysore-India which can train 12,000 trainees at time. I am very excited to work in that training centre"
    }, {
        "employer": "Internshala",
        "title": "Brand Ambassador",
        "dates": "jan 2016 - may 2016",
        "location": "Gujarat",
        "description": "Internshala is one of the biggest online concern in India which provides the students with internships in the leading companies of India. The main office is situated in Gurgon and It functions all over India having 32 branches."
    }]
};


work.display = function() {
    work.jobs.forEach(function(job) {

        $("#workExperience").append(HTMLworkStart);

        var formattedemployer = HTMLworkEmployer.replace("%data%", job.employer);
        var formattedtitle = HTMLworkTitle.replace("%data%", job.title);
        var formattedemployertitle = formattedemployer + formattedtitle;
        $(".work-entry:last").append(formattedemployertitle);

        var formatteddate = HTMLworkDates.replace("%data%", job.dates);
        $(".work-entry:last").append(formatteddate);

        var formattedlocation = HTMLworkLocation.replace("%data%", job.location);
        $(".work-entry:last").append(formattedlocation);

        var formatteddescription = HTMLworkDescription.replace("%data%", job.description);
        $(".work-entry:last").append(formatteddescription);
    });
};

work.display();


var projects = {
    "projects": [{
        "title": "Portfolio",
        "dates": "july 2016 - october 2016",
        "description": "This project is about creating our own Portfolio web-site using CSS, HTML, Java-script. It gives us confidence to design a web-site in our own. It's all about unique art the people possess. Each one can create their own design and build their own personal website.",
        "images": ["images/197x148.gif", "images/197x148.gif"]

    }]
};

projects.display = function() {

    projects.projects.forEach(function(project) {

        $("#projects").append(HTMLprojectStart);

        var formattedtitle = HTMLprojectTitle.replace("%data%", project.title);

        $(".project-entry:last").append(formattedtitle);

        var formatteddates = HTMLprojectDates.replace("%data%", project.dates);

        $(".project-entry:last").append(formatteddates);

        var formatteddescription = HTMLprojectDescription.replace("%data%", project.description);

        $(".project-entry:last").append(formatteddescription);

        project.images.forEach(function(image) {

            var formattedimg = HTMLprojectImage.replace("%data%", image);
            $(".project-entry:last").append(formattedimg);
        });
    });
};

projects.display();

var education = {
    "schools": [{
        "name": "B.V.B",
        "degree": "Highschool",
        "location": "Erode",
        "majors": ['CSE'],
        "dates": "May 2010 - June2012",
        "url": "http://www.actedu.in/bharathi-vidya-bhavan-erode/"
    }, {
        "name": "ANNA UNIVERSITY",
        "degree": "B.Tech",
        "location": "Chennai",
        "majors": ['Chemical Engineering'],
        "dates": "May 2012 - June2016",
        "url": "https://www.annauniv.edu/"
    }],
    "onlineCourses": [{
        "title": "FEND",
        "school": "Udacity",
        "dates": "Aug 2016 - Dec 2016",
        "url": "http://www.udacity.com/"
    }]
};

education.display = function() {
    education.schools.forEach(function(educations) {

        $("#education").append(HTMLschoolStart);
        var formattedname = HTMLschoolName.replace("%data%", educations.name);
        var formatteddegree = HTMLschoolDegree.replace("%data%", educations.degree);
        var formattednamedegree = formattedname + formatteddegree;
        $(".education-entry:last").append(formattednamedegree);
        var formattedlocation = HTMLschoolLocation.replace("%data%", educations.location);
        $(".education-entry:last").append(formattedlocation);
        var formatteddates = HTMLschoolDates.replace("%data%", educations.dates);
        $(".education-entry:last").append(formatteddates);
        var formattedmajors = HTMLschoolMajor.replace("%data%", educations.majors);
        $(".education-entry:last").append(formattedmajors);
        var formattedURL = HTMLschoolURL.replace("%data%", educations.url);
        $(".education-entry:last").append(formattedURL);

    });
    $("#education").append(HTMLonlineClasses);
    education.onlineCourses.forEach(function(onlineCourse) {

        $("#education").append(HTMLschoolStart);

        var formattedonlinetitle = HTMLonlineTitle.replace("%data%", onlineCourse.title);
        var formattedonlineschool = HTMLonlineSchool.replace("%data%", onlineCourse.school);
        var formattedtitleschool = formattedonlinetitle + formattedonlineschool;
        $(".education-entry:last").append(formattedtitleschool);

        var formattedonlinedates = HTMLonlineDates.replace("%data%", onlineCourse.dates);
        $(".education-entry:last").append(formattedonlinedates);

        var formattedonlineurl = HTMLonlineURL.replace("%data%", onlineCourse.url);
        $(".education-entry:last").append(formattedonlineurl);

    });


};

education.display();


$("#mapDiv").append(googleMap);